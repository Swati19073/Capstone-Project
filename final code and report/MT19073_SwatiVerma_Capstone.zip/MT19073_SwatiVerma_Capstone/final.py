from flask import Flask, render_template, request, redirect,url_for
from flaskext.mysql import MySQL
from flask_wtf import FlaskForm
from wtforms import SelectField
from flaskext.mysql import MySQL
from logging.config import dictConfig


app=Flask(__name__)

mysql=MySQL()
app.config['MYSQL_DATABASE_HOST'] ='localhost'
app.config['MYSQL_DATABASE_USER'] ='root'
app.config['MYSQL_DATABASE_PASSWORD'] =''
app.config['MYSQL_DATABASE_DB'] ='capstone'

mysql.init_app(app)


@app.route('/' ,methods=['GET','POST'])
def index():

	return render_template('home.html')


@app.route('/home')
def home():
	return render_template('home.html')
	

@app.route('/diem')
def diem():
	return render_template('diem.html')


@app.route('/backlog')
def backlog():
	return render_template('backlog.html')
	
@app.route('/decision' ,methods=['GET','POST'])
def decision():
	if request.method=='POST':
		decision=request.form
		decision_name=decision['txt_decision']
		if(len(decision_name)>0):
			conn=mysql.connect()
			cur=conn.cursor()
			cur.execute("select * from decisions")
			records=cur.fetchall()
			cur.execute("INSERT INTO decisions  (decision_name) VALUES (%s)",(decision_name))
			conn.commit()
			cur.close()
		

	return render_template('decision.html')


@app.route('/action',methods=['GET','POST'] )
def action():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		action_name=request.form['txt_action']
		if(len(decision_name)>0):
			
			cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
			records=cur.fetchall()
			decision_id2=""
			for row in records:
				decision_id2=row[0]
			app.logger.info('decision id is %s',decision_id2)
			
			cur.execute("select * from actions")
			records=cur.fetchall()
				
			cur.execute("INSERT INTO actions (action_name,decision_id) VALUES (%s,%s)",(action_name,decision_id2))
			conn.commit()
			cur.close()
			return redirect(url_for('action_object',action_name=action_name))
			
	return render_template('action.html',decision_options=decisions_entered)

@app.route('/uncertainty',methods=['GET','POST'] )
def uncertainty():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		uncertainty_name=request.form['txt_uncertainty']
		if(len(uncertainty_name)>0):
			
			cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
			records=cur.fetchall()
			decision_id2=""
			for row in records:
				decision_id2=row[0]
			app.logger.info('decision id is %s',decision_id2)
			
			cur.execute("select * from uncertainties")
			records=cur.fetchall()
				
			cur.execute("INSERT INTO uncertainties (uncertainty_name,decision_id) VALUES (%s,%s)",(uncertainty_name,decision_id2))
			conn.commit()
			cur.close()
			return redirect(url_for('uncertainty_object',uncertainty_name=uncertainty_name))
			
	return render_template('uncertainty.html',decision_options=decisions_entered)	



@app.route('/objective',methods=['GET','POST'] )
def objective():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		objective_name=request.form['txt_objective']
		app.logger.info('objective name is %s',objective_name)
		if(len(objective_name)>0):
			
			cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
			records=cur.fetchall()
			decision_id2=""
			for row in records:
				decision_id2=row[0]
			app.logger.info('decision id is %s',decision_id2)
			
			cur.execute("select * from objectives")
			records=cur.fetchall()
				
			cur.execute("INSERT INTO objectives (objective_name,decision_id) VALUES (%s,%s)",(objective_name,decision_id2))
			conn.commit()
			cur.close()
			return redirect(url_for('objective_object',objective_name=objective_name))
			
				
	return render_template('objective.html',decision_options=decisions_entered)		


# 

@app.route('/action_object',methods=['GET','POST'] )
def action_object():
	if request.method=='POST':
		action_name=request.args.get('action_name')
		app.logger.info('action name is %s',action_name)
		attr1=request.form['attr1']
		dtype1=request.form['slct_dtype1']
		atype1=request.form['slct_attr_type']
		attr=request.form.getlist('attrd[]')
		dtype=request.form.getlist('dtype[]')
		atype=request.form.getlist('atype[]')
		conn=mysql.connect()
		cur=conn.cursor()
		cur.execute("Select action_id from actions where action_name=(%s)",(action_name));
		records=cur.fetchall();
		action_id=""
		for row in records:
			action_id=row[0]
		flag=0
		for i in atype:
			if i=='derived' or atype1=='derived':
				flag=1
		app.logger.info('atypeis %s',atype1)
		if(len(attr1)>0 and dtype1!="0" and atype1 !="0"):
			cur.execute("INSERT INTO action_attr (action_id,attr_name,data_type,attr_type) VALUES (%s,%s,%s,%s)",(action_id,attr1,dtype1,atype1))
			conn.commit()
		if(len(attr)>0):
			for i in range(len(attr)):
				if(len(attr[i])>0 and dtype[i]!="0" and atype[i]!=0):
					cur.execute("INSERT INTO action_attr (action_id,attr_name,data_type,attr_type) VALUES (%s,%s,%s,%s)",(action_id,attr[i],dtype[i],atype[i]))
					conn.commit()
		cur.close()
		if flag==0:
			return render_template('action_object.html')
		else:
			return redirect(url_for('base_derived_action_attri',action_name=action_name))
		# return render_template('action_object.html',action_name=action_name)	
	return render_template('action_object.html')	



@app.route('/base_derived_action_attri',methods=['GET','POST'] )
def base_derived_action_attri():
	action_name=request.args.get('action_name')
	app.logger.info('action name is %s',action_name)
	conn=mysql.connect()
	cur=conn.cursor()
	resultVal1=cur.execute("Select action_id from actions where action_name=(%s)",(action_name))
	resFree1=cur.fetchall()
	action_id=resFree1[0]
	resultVal2=cur.execute("Select attr_name from action_attr where action_id=(%s) and attr_type= 'base' ",(action_id))
	resFree2=cur.fetchall()
	app.logger.info('base attribute name is %s',resFree2)
	base_temp=[]
	der_temp=[]
	for i in resFree2:
		base_temp.append(i[0])
	resultVal3=cur.execute("Select attr_name from action_attr where action_id=(%s) and attr_type= 'derived' ",(action_id))
	resFree3=cur.fetchall()
	for j in resFree3:
		der_temp.append(j[0])
		base_temp.append(j[0])
	derived_attribute=tuple(der_temp)
	base_attribute=tuple(base_temp)
	app.logger.info('derived attribute name is %s',derived_attribute)
	conn.commit()
	cur.close()
	if request.method=='POST':
		conn1=mysql.connect()
		cur1=conn1.cursor()
		derived_attr=str(request.form['select_derived'])
		base_attr=request.form.getlist('select_base')
		app.logger.info('action name is %s',base_attr)
		print("base attribuutes are  " ,base_attr)
		for b in base_attr:
			cur1.execute("INSERT INTO action_attr_dep (action_id, attr_name, child_name) VALUES (%s,%s,%s)",(action_id,derived_attr,b))
		conn1.commit()
		cur1.close()
		return render_template('base_derived_action_attri.html', derived_attribute=derived_attribute, base_attribute=base_attribute)
	return render_template('base_derived_action_attri.html', derived_attribute=derived_attribute, base_attribute=base_attribute)
		






@app.route('/objective_object',methods=['GET','POST'] )
def objective_object():
	if request.method=='POST':
		objective_name=request.args.get('objective_name')
		app.logger.info('objective name is %s',objective_name)
		attr1=request.form['attr1']
		atype1=request.form['slct_attr_type']
		dtype1=request.form['slct_dtype1']
		attr=request.form.getlist('attrd[]')
		dtype=request.form.getlist('dtype[]')
		atype=request.form.getlist('atype[]')
		conn=mysql.connect()
		cur=conn.cursor()
		cur.execute("Select objective_id from objectives where objective_name=(%s)",(objective_name));
		records=cur.fetchall();
		objective_id=""
		for row in records:
			objective_id=row[0]

		flag=0
		for i in atype:
			if i=='derived' or atype1=='derived':
				flag=1
		
		app.logger.info('objective id is %s',objective_id)

		app.logger.info('attr name is %s',attr1)
		app.logger.info('dtypeis %s',dtype1)
		if(len(attr1)>0 and dtype1!="0"):
			cur.execute("INSERT INTO objective_attr (objective_id,attr_name,data_type,computable_attr) VALUES (%s,%s,%s,%s)",(objective_id,attr1,dtype1,atype1))
			conn.commit()
		if(len(attr)>0 ):
			for i in range(len(attr)):
				if(len(attr[i])>0 and dtype[i]!="0"):
					cur.execute("INSERT INTO objective_attr (objective_id,attr_name,data_type,computable_attr) VALUES (%s,%s,%s,%s)",(objective_id,attr[i],dtype[i],atype[i]))
					conn.commit()
		cur.close()
		if flag==0:
			return render_template('objective_object.html')
		else:
			return redirect(url_for('objective_object',objective_name=objective_name))
	return render_template('objective_object.html')	



@app.route('/uncertainty_object',methods=['GET','POST'] )
def uncertainty_object():
	if request.method=='POST':
		uncertainty_name=request.args.get('uncertainty_name')
		app.logger.info('uncertainty name is %s',uncertainty_name)
		attr1=request.form['attr1']
		# atype1=request.form['slct_attr_type']
		dtype1=request.form['slct_dtype1']
		attr=request.form.getlist('attrd[]')
		dtype=request.form.getlist('dtype[]')
		# atype=request.form.getlist('atype[]')
		conn=mysql.connect()
		cur=conn.cursor()
		cur.execute("Select uncertainty_id from uncertainties where uncertainty_name=(%s)",(uncertainty_name));
		records=cur.fetchall();
		uncertainty_id=""
		for row in records:
			uncertainty_id=row[0]
		# flag=0
		# for i in atype:
		# 	if i=='derived' or atype1=='derived':
		# 		flag=1

		
		app.logger.info('uncertainty id is %s',uncertainty_id)

		app.logger.info('attr name is %s',attr1)
		app.logger.info('dtypeis %s',dtype1)
		if(len(attr1)>0 and dtype1!="0"):
			cur.execute("INSERT INTO uncertainty_attr (uncertainty_id,attr_name,data_type) VALUES (%s,%s,%s)",(uncertainty_id,attr1,dtype1))
			conn.commit()
		if(len(attr)>0):
			for i in range(len(attr)):
				if(len(attr[i])>0 and dtype[i]!="0"):
					cur.execute("INSERT INTO uncertainty_attr (uncertainty_id,attr_name,data_type) VALUES (%s,%s,%s)",(uncertainty_id,attr[i],dtype[i]))
					conn.commit()
		cur.close()
		# if flag==0:
		# 	return render_template('uncertainty_object.html')
		# else:
		return redirect(url_for('uncertainty_object',uncertainty_name=uncertainty_name))
	return render_template('uncertainty_object.html')	



@app.route('/modify_decision',methods=['GET','POST'] )
def modify_decision():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		option=str(request.form['options'])
		if(option=="modify"):
			new_decision_name=str(request.form['decision_name'])
			app.logger.info('new decision name is %s',new_decision_name)
			app.logger.info('action to be performed is %s',option)
			cur.execute("update decisions set decision_name=(%s) where decision_name = (%s)",(new_decision_name,decision_name))
			conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
			return render_template('modify_decision.html',decision_options=decisions_entered)

		else:
			app.logger.info('action to be performed is %s',option)
			cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
			records=cur.fetchall()
			decision_id2=0
			for row in records:
				decision_id2=row[0]
			decision_id3=int(decision_id2)
			if(decision_id3!=0):
				cur.execute("delete  from decisions where decision_id=(%s)",(decision_id3))
				conn.commit()
				result=cur.execute("select * from decisions")
				decisions_entered=cur.fetchall()
				return render_template('modify_decision.html',decision_options=decisions_entered)
		cur.close()
		
	return render_template('modify_decision.html',decision_options=decisions_entered)

@app.route('/modify_action1',methods=['GET','POST'] )
def modify_action1():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
		records=cur.fetchall()
		decision_id2=0
		for row in records:
			decision_id2=row[0]
		decision_id2=int(decision_id2)
		app.logger.info('decision id is %d',decision_id2)
		if(decision_id2!=0):
			
			cur.execute("select action_name from actions where decision_id=(%s)",(decision_id2))
			action_names=cur.fetchall()
			conn.commit()
			cur.close()
			if(cur.rowcount==0):
				action_list=['None']
				comma_separated = ','.join(action_list)
				return(redirect(url_for('modify_action2',actions=comma_separated)))
			# app.logger.info('action names are%s',action_names)
			else:
				action_list=[]
				for i in action_names:
					action_list.append(i[0])

				comma_separated = ','.join(action_list)
				return redirect(url_for('modify_action2',actions=comma_separated))
			# return render_template('modify_action2.html',actions=action_names)
	return render_template('modify_action1.html',decision_options=decisions_entered)

@app.route('/modify_action2',methods=['GET','POST'] )
def modify_action2():
	

	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		action_name=str(request.form["slct_action"])
		app.logger.info('action name is %d',action_name)
		option=str(request.form['options'])
		if(option=="delete"):
			app.logger.info('action to be performed is %s',option)
			cur.execute("select action_id from actions where action_name = (%s)",(action_name))
			records=cur.fetchall()
			action_id=0
			for row in records:
				action_id=row[0]
			action_id2=int(action_id)
			if(action_id2!=0):
				cur.execute("delete from actions where action_id=(%s)",(action_id2))
				conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
		elif(option=="modify_name"):
			action_name_new=str(request.form['action_name'])
			app.logger.info('action to be performed is %s',option)
			cur.execute("select action_id from actions where action_name = (%s)",(action_name))
			records=cur.fetchall()
			action_id=0
			for row in records:
				action_id=row[0]
			action_id3=int(action_id)
			if(action_id3!=0):
				cur.execute("update actions set action_name =%s where action_id=(%s)",(action_name_new,action_id3))
				conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
			return redirect(url_for('modify_action1',decision_options=decisions_entered))

	return render_template('modify_action2.html')





@app.route('/modify_objective1',methods=['GET','POST'] )
def modify_objective1():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
		records=cur.fetchall()
		decision_id2=0
		for row in records:
			decision_id2=row[0]
		decision_id2=int(decision_id2)
		app.logger.info('decision id is %d',decision_id2)
		if(decision_id2!=0):
			
			cur.execute("select objective_name from objectives where decision_id=(%s)",(decision_id2))
			action_names=cur.fetchall()
			conn.commit()
			cur.close()
			if(cur.rowcount==0):
				action_list=['None']
				comma_separated = ','.join(action_list)
				return(redirect(url_for('modify_objective2',actions=comma_separated)))
			# app.logger.info('action names are%s',action_names)
			else:
				action_list=[]
				for i in action_names:
					action_list.append(i[0])

				comma_separated = ','.join(action_list)
				return redirect(url_for('modify_objective2',actions=comma_separated))
			# return render_template('modify_action2.html',actions=action_names)
	return render_template('modify_objective1.html',decision_options=decisions_entered)



@app.route('/modify_objective2',methods=['GET','POST'] )
def modify_objective2():
	if request.method=='POST':
		conn=mysql.connect()
		cur=conn.cursor()
		action_name=str(request.form["slct_action"])
		app.logger.info('action name is %d',action_name)
		option=str(request.form['options'])
		if(option=="delete"):
			app.logger.info('action to be performed is %s',option)
			cur.execute("select objective_id from objectives where objective_name = (%s)",(action_name))
			records=cur.fetchall()
			action_id=0
			for row in records:
				action_id=row[0]
			action_id2=int(action_id)
			if(action_id2!=0):
				cur.execute("delete from objectives where objective_id=(%s)",(action_id2))
				conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
		elif(option=="modify_name"):
			action_name_new=str(request.form['action_name'])
			app.logger.info('action to be performed is %s',option)
			cur.execute("select objective_id from objectives where objective_name = (%s)",(action_name))
			records=cur.fetchall()
			action_id=0
			for row in records:
				action_id=row[0]
			action_id3=int(action_id)
			if(action_id3!=0):
				cur.execute("update objectives set objective_name =%s where objective_id=(%s)",(action_name_new,action_id3))
				conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
			return redirect(url_for('modify_objective1',decision_options=decisions_entered))

	return render_template('modify_objective2.html')





@app.route('/modify_uncertainty1',methods=['GET','POST'] )
def modify_uncertainty1():
	
	conn=mysql.connect()
	cur=conn.cursor()
	result=cur.execute("select * from decisions")
	decisions_entered=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		decision_name=str(request.form['slct_decision'])
		app.logger.info('decision name is %s',decision_name)
		cur.execute("select decision_id from decisions where decision_name = (%s)",(decision_name))
		records=cur.fetchall()
		decision_id2=0
		for row in records:
			decision_id2=row[0]
		decision_id2=int(decision_id2)
		app.logger.info('decision id is %d',decision_id2)
		if(decision_id2!=0):
			cur.execute("select uncertainty_name from uncertainties where decision_id=(%s)",(decision_id2))
			action_names=cur.fetchall()
			conn.commit()
			cur.close()
			if(cur.rowcount==0):
				action_list=['None']
				comma_separated = ','.join(action_list)
				return(redirect(url_for('modify_uncertainty2',actions=comma_separated)))
			# app.logger.info('action names are%s',action_names)
			else:
				action_list=[]
				for i in action_names:
					action_list.append(i[0])

				comma_separated = ','.join(action_list)
				return redirect(url_for('modify_uncertainty2',actions=comma_separated))
			# return render_template('modify_action2.html',actions=action_names)
	return render_template('modify_uncertainty1.html',decision_options=decisions_entered)				



@app.route('/modify_uncertainty2',methods=['GET','POST'] )
def modify_uncertainty2():
	

	if request.method=='POST':
		
		conn=mysql.connect()
		cur=conn.cursor()
		action_name=str(request.form["slct_action"])
		# app.logger.info('action name is %d',action_name)
		option=str(request.form['options'])
		if(option=="delete"):
			app.logger.info('action to be performed is %s',option)
			cur.execute("select uncertainty_id from uncertainties where uncertainty_name = (%s)",(action_name))
			records=cur.fetchall()
			action_id=0
			for row in records:
				action_id=row[0]
			action_id2=int(action_id)
			if(action_id2!=0):
				cur.execute("delete from uncertainties where uncertainty_id=(%s)",(action_id2))
				conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
		elif(option=="modify_name"):
			action_name_new=str(request.form['action_name'])
			app.logger.info('action to be performed is %s',option)
			cur.execute("select uncertainty_id from uncertainties where uncertainty_name = (%s)",(uncertainty_name))
			records=cur.fetchall()
			action_id=0
			for row in records:
				action_id=row[0]
			action_id3=int(action_id)
			if(action_id3!=0):
				cur.execute("update uncertainties set uncertainty_name =%s where uncertainty_id=(%s)",(action_name_new,action_id3))
				conn.commit()
			result=cur.execute("select * from decisions")
			decisions_entered=cur.fetchall()
			return redirect(url_for('modify_uncertainty1',decision_options=decisions_entered))

	return render_template('modify_uncertainty2.html')

			
	

# @app.route('/decision_tool')
# def decision_tool():
# 	conn=mysql.connect()
# 	cur=conn.cursor()
# 	resultVal=cur.execute("Select * from decisions")
# 	print(resultVal)
# 	if(resultVal>0):
# 		decisionsDetails=cur.fetchall()
# 		return render_template('decision_tool.html', decisionsDetails=decisionsDetails)	
# 	conn.commit()
# 	cur.close()
# 	return render_template('decision_tool.html')


def storeDecision(inputList):
    conn=mysql.connect()
    cur=conn.cursor()
    if( str(inputList[2]) == str(1) ):
        cur.execute( "INSERT INTO free_decisions(decision_id,decision_name) VALUES (%s,%s)",(inputList[0],inputList[1]))
    elif( str(inputList[2]) == str(2)) :
        cur.execute( " INSERT INTO composite_decision(decision_id,decision_name) VALUES (%s,%s)",(inputList[0],inputList[1]))
    elif( str(inputList[2]) == str(3)) :
        cur.execute( " INSERT INTO specialized_decision(decision_id,decision_name) VALUES (%s,%s)",(inputList[0],inputList[1]))
    conn.commit()
    cur.close()
    

@app.route('/decision_tool',methods=['GET','POST'])
def decision_tool():
	conn=mysql.connect()
	cur=conn.cursor()
	resultVal=cur.execute("Select * from decisions")
	print(resultVal)
	if(resultVal>0):
		decisionsDetails=cur.fetchall()
	conn.commit()
	cur.close()
	if request.method == 'POST':
		a = 0
		data = request.form
		for id in data.items():
		    a += 1
		    list = []
		    decision_id = request.form.get('decision_id'+str(a))
		    decision_name=request.form.get('decision_name'+str(a))
		    decision_type=request.form.get('slct_decision_type'+str(a))
		    list.append(decision_id);
		    list.append(decision_name);
		    list.append(decision_type);
		    storeDecision(list)
		# conn=mysql.connect()
		# cur=conn.cursor()
		# resultVal=cur.execute("Select decision_id,decision_name from composite_decision")
		# if(resultVal>0):
		# 	decisionsDetails=cur.fetchall()
		# 	return render_template('decision_tool.html', decisionsDetails=decisionsDetails)
		# conn.commit()
		# cur.close()
	return render_template('decision_tool.html', decisionsDetails=decisionsDetails)	
    # return render_template('decision_tool.html', decisionsDetails=decisionsDetails)		

def initialSetPriorityUsingChildren(decision_parent,decision_type):
    conn=mysql.connect()
    cur=conn.cursor()
    if( str(decision_type) == 'composite'):
        cur.execute(" update composite_decision as S inner join ( select parent_name,sum(decision_syn_priority) as fin_pr from composite_decision as f where parent_name = %s group by parent_name) as fin on fin.parent_name = S.decision_name set S.decision_syn_priority=fin.fin_pr ",(decision_parent))
    elif( str(decision_type) == 'specialized'):
        cur.execute(" update specialized_decision as S inner join ( select parent_name,sum(decision_syn_priority) as fin_pr from specialized_decision as f where parent_name = %s group by parent_name) as fin on fin.parent_name = S.decision_name set S.decision_syn_priority=fin.fin_pr ",(decision_parent))
    conn.commit()
    cur.close()


def setparentSynPriority(decision_name,decision_type,listLength):
    conn=mysql.connect()
    cur=conn.cursor()
    if( str(decision_type) == 'composite'):
        cur.execute("update composite_decision set decision_syn_priority = decision_syn_priority + %s where decision_name = %s",(listLength,decision_name))
    elif( str(decision_type) == 'specialized'):
        cur.execute("update specialized_decision set decision_syn_priority = decision_syn_priority + %s where decision_name = %s",(listLength,decision_name))
    conn.commit()
    cur.close()



def updateParentSynPriorityIfNeeded(decision_name,decision_type):
    conn=mysql.connect()
    cur=conn.cursor()
    if( str(decision_type) == 'composite'):
        while True:
            resultVal= cur.execute("select * from composite_decision where decision_name= %s",decision_name)
            if(resultVal>0):
                decision_detail = cur.fetchone();
                if(decision_detail[6] is not None):
                    setparentSynPriority(decision_detail[6],decision_type,decision_detail[3])
                    decision_name=decision_detail[6]
                else:
                    break
    elif( str(decision_type) == 'specialized'):
        while True:
            resultVal= cur.execute("select * from specialized_decision where decision_name= %s",decision_name)
            if(resultVal>0):
                decision_detail = cur.fetchone();
                if(decision_detail[6] is not None):
                    setparentSynPriority(decision_detail[6],decision_type,decision_detail[3])
                    decision_name=decision_detail[6]
                else:
                    break
    conn.commit()
    cur.close()
    
def setParentAndRoot(decision_name,decision_type):
    conn=mysql.connect()
    cur=conn.cursor()
    if( str(decision_type) == 'composite'):
        cur.execute("select parent_name from composite_decision where decision_name= %s",decision_name)
        decision_detail = cur.fetchone();
        print( "curemt parent of :" + str(decision_name) + "is:" + str(decision_detail))
        if(decision_detail[0] is None):
            cur.execute("update composite_decision set is_parent=1,is_root=1 where decision_name = %s",decision_name)
        else:
            cur.execute("update composite_decision set is_parent=1 where decision_name = %s",decision_name)
        conn.commit()
    elif( str(decision_type) == 'specialized'):
        cur.execute("select parent_name from specialized_decision where decision_name= %s",decision_name)
        decision_detail = cur.fetchone();
        if(decision_detail[0] is None):
            cur.execute("update specialized_decision set is_parent=1,is_root=1 where decision_name = %s",decision_name)
        else:
            cur.execute("update specialized_decision set is_parent=1 where decision_name = %s",decision_name)
        conn.commit()
    cur.close()
    
    
    
def updateChildren(decision_parent,child_decision,decision_type):
    conn=mysql.connect()
    cur=conn.cursor()
    if( str(decision_type) == 'composite'):
        cur.execute("update composite_decision set is_root=0,parent_name = %s where decision_name = %s",(decision_parent,child_decision))
    elif( str(decision_type) == 'specialized'):
        cur.execute("update specialized_decision set is_root=0,parent_name = %s where decision_name = %s",(decision_parent,child_decision))
    conn.commit()
    cur.close()
    





@app.route('/get_composite_dependencies',methods=['GET','POST'])	
def get_composite_dependencies(): 
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("Select decision_id,decision_name from composite_decision")
    decisionsDetails=cur.fetchall()
    conn.commit()
    cur.close()
    
    if request.method == 'POST':
        multiselect = request.form.getlist('decision_child')
        decision_parent=request.form.get('decision_parent')
        print( 'child:-' + str(multiselect))
        print('parent:-' + str(decision_parent))
        setParentAndRoot(decision_parent,'composite')
        for child_decision in multiselect:
            updateChildren(decision_parent,child_decision,'composite')
        initialSetPriorityUsingChildren(decision_parent,'composite')
        app.logger.info('length of multiselect is %s', len(multiselect))
        setparentSynPriority(decision_parent,'composite',len(multiselect))
        updateParentSynPriorityIfNeeded(decision_parent,'composite')
        """ check for cycle dependcies is still left"""
        return render_template('get_composite_depedencies.html', decisionsDetails=decisionsDetails)
    elif request.method == 'GET':
        return render_template('get_composite_depedencies.html', decisionsDetails=decisionsDetails)
    return render_template('get_composite_depedencies.html', decisionsDetails=decisionsDetails)


@app.route('/get_specialized_dependencies',methods=['GET','POST'])	
def get_specialized_dependencies(): 
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("Select decision_id,decision_name from specialized_decision")
    decisionsDetails=cur.fetchall()
    conn.commit()
    cur.close()
    
    if request.method == 'POST':
        multiselect = request.form.getlist('decision_child')
        decision_parent=request.form.get('decision_parent')
        print( 'child:-' + str(multiselect))
        print('parent:-' + str(decision_parent))
        setParentAndRoot(decision_parent,'specialized')
        for child_decision in multiselect:
            updateChildren(decision_parent,child_decision,'specialized')
        initialSetPriorityUsingChildren(decision_parent,'specialized')
        setparentSynPriority(decision_parent,'specialized',len(multiselect))
        updateParentSynPriorityIfNeeded(decision_parent,'specialized')
        """ check for cycle dependcies is still left"""
        return render_template('get_specialized_dependencies.html', decisionsDetails=decisionsDetails)
    elif request.method == 'GET':
        return render_template('get_specialized_dependencies.html', decisionsDetails=decisionsDetails)     
    return render_template('get_specialized_dependencies.html', decisionsDetails=decisionsDetails)
""" swati code"""

@app.route('/dependency', methods=['GET', 'POST'])
def dependency():
    temp_tuples = []
    free_desc = []
    comp_desc = []
    sp_desc = []
    conn = mysql.connect()
    cur = conn.cursor()
    resultVal = cur.execute('Select * from free_decisions')
    resFree = cur.fetchall()
    for i in range(len(resFree)):
        temp_tuples.append(resFree[i][1])
        free_desc.append(resFree[i][1])
    conn.commit()
    cur.close()
    conn1 = mysql.connect()
    cur1 = conn1.cursor()
    resultVal1 = \
        cur1.execute('Select * from composite_decision where is_root=1')
    resCompo = cur1.fetchall()
    for j in range(len(resCompo)):
        temp_tuples.append(resCompo[j][1])
        comp_desc.append(resCompo[j][1])
    conn2 = mysql.connect()
    cur2 = conn1.cursor()
    resultVal2 = \
        cur2.execute('Select * from specialized_decision where is_root=1'
       )
    resSpecial = cur2.fetchall()
    for k in range(len(resSpecial)):
        temp_tuples.append(resSpecial[k][1])
        sp_desc.append(resSpecial[k][1])

    finalTuples = tuple(temp_tuples)

    conn.commit()
    cur.close()
    conn1.commit()
    cur1.close()
    conn2.commit()
    cur2.close()

    if request.method == 'POST':
        conn3 = mysql.connect()
        cur3 = conn3.cursor()
        parent_name = str(request.form['selct_decision1'])
        child_name = str(request.form['selct_decision2'])
        app.logger.info('parent name is %s', parent_name)
        app.logger.info('child name is %s', child_name)
        parent_type = None
        child_type = None

        # # action_name=request.form['txt_action']

        if len(parent_name) > 0:
            if parent_name in free_desc:
                cur3.execute('select * from free_decisions where decision_name = (%s)'
                             , parent_name)
                records1 = cur3.fetchone()
                parent_type = 0
            elif parent_name in comp_desc:
                cur3.execute('select * from composite_decision where decision_name = (%s)'
                             , parent_name)
                records1 = cur3.fetchone()
                parent_type = 2
            elif parent_name in sp_desc:
                cur3.execute('select * from specialized_decision where decision_name = (%s)'
                             , parent_name)
                records1 = cur3.fetchone()
                parent_type = 1 

        if len(child_name) > 0:
            if child_name in free_desc:
                cur3.execute('select * from free_decisions where decision_name = (%s)'
                             , child_name)
                records2 = cur3.fetchone()
                child_type = 0
            elif child_name in comp_desc:

                cur3.execute('select * from composite_decision where decision_name = (%s)'
                             , child_name)
                records2 = cur3.fetchone()
                child_type = 2
            elif child_name in sp_desc:

                cur3.execute('select * from specialized_decision where decision_name = (%s)'
                             , child_name)
                records2 = cur3.fetchone()
                child_type = 1

        cur3.execute('INSERT INTO final_dep ( parent_name,child_name,parent_type,child_type) VALUES (%s,%s,%s,%s)'
                     , (parent_name, child_name, parent_type,
                     child_type))
        conn3.commit()
        cur3.close()
        return render_template('dependency.html',
                               finalTuples=finalTuples)

        # return redirect(url_for('action_object',action_name=action_name))

    return render_template('dependency.html', finalTuples=finalTuples)
    
class Decisions:
    decision_name = None
    decision_csyn_priority = 0
    decision_ssyn_priority = 0
    decision_sementic_priority = 0
    decision_type  = 0
    def __init__(self, decision_name, decision_csyn_priority,decision_ssyn_priority,decision_sementic_priority,decision_type):
        self.decision_name = decision_name
        self.decision_csyn_priority = decision_csyn_priority
        self.decision_ssyn_priority = decision_ssyn_priority
        self.decision_sementic_priority = decision_sementic_priority
        self.decision_type = decision_type
        
class Childrens:
    decision_name = None
    decision_csyn_priority = 0
    decision_ssyn_priority = 0
    decision_sementic_priority = 0
    decision_parent_name = None
    decision_is_root = 0
    decision_is_parent=0
    decision_type  = 0
    def __init__(self, decision_name,decision_sementic_priority, decision_csyn_priority,decision_ssyn_priority,decision_is_parent,decision_is_root,decision_parent_name,decision_type):
        self.decision_name = decision_name
        self.decision_csyn_priority = decision_csyn_priority
        self.decision_ssyn_priority = decision_ssyn_priority
        self.decision_sementic_priority = decision_sementic_priority
        self.decision_type = decision_type  
        self.decision_parent_name = decision_parent_name
        self.decision_is_root = decision_is_root
        self.decision_is_parent=decision_is_parent
      
def getBacklogList(decision_type):
    conn=mysql.connect()
    cur=conn.cursor()
    csyn_priority = None
    ssyn_priority = None
    decision_type_int = 0
    if decision_type == 'free':
        resultVal=cur.execute("select * from free_decisions f where is_visited=false and f.decision_name not in (select g.child_name from final_dep g where g.child_name = f.decision_name and is_visited = 0)")
        decision_type_int=0
        csyn_priority=0
        ssyn_priority=0
        
    elif decision_type == 'composite':
        resultVal=cur.execute("select * from composite_decision f where is_visited=false and is_root=1 and f.decision_name not in (select g.child_name from final_dep g where g.child_name = f.decision_name and is_visited = 0)")
        decision_type_int=2
        ssyn_priority=0
        
    elif decision_type == 'specialized':
        resultVal=cur.execute("select * from specialized_decision f where is_visited=false and is_root=1 and f.decision_name not in (select g.child_name from final_dep g where g.child_name = f.decision_name and is_visited = 0)")
        decision_type_int=1
        csyn_priority=0
    
    resFree=cur.fetchall()
    conn.commit()
    cur.close()
    finalList = []
    for i in range(len(resFree)):
        if decision_type == 'composite':
            csyn_priority = resFree[i][3]
        elif decision_type == 'specialized':
            ssyn_priority = resFree[i][3]
        i = Decisions(resFree[i][1],csyn_priority,ssyn_priority,0,decision_type_int)
        finalList.append(i)
    return finalList
    
def insertIntoBacklog(decision_name,decision_csyn_priority,decision_ssyn_priority,decision_type,decision_priority):
    conn=mysql.connect()
    cur=conn.cursor()
    if decision_name is not None:
        cur.execute( "INSERT into backlog values(Null,%s,%s,%s,%s,%s)",(decision_name,decision_csyn_priority,decision_ssyn_priority,decision_priority,decision_type))
        conn.commit()
    cur.close()
    
 
    

def getAllIndepedentDecision():
    app.logger.info('here in getAllIndepedentDecision method')
    finalBacklogList = []
    freeBacklogList = getBacklogList("free")
    compositeBacklogList = getBacklogList("composite")
    specializedBacklogList = getBacklogList("specialized")
    for j in range(len(freeBacklogList)):
        finalBacklogList.append(freeBacklogList[j])
    for k in range(len(specializedBacklogList)):
        finalBacklogList.append(specializedBacklogList[k])
    for l in range(len(compositeBacklogList)):
        finalBacklogList.append(compositeBacklogList[l])
    return finalBacklogList
    
def getAllChildren(current_decision_object):
    app.logger.info('Here in getAllChildren')
    app.logger.info('For Decision :- %s',current_decision_object.decision_name)
    conn=mysql.connect()
    cur=conn.cursor()
    childList = []
    rowCount = 0
    if int(current_decision_object.decision_type) == 1 :
        resultVal=cur.execute( "select * from specialized_decision where parent_name=%s ",current_decision_object.decision_name)
    elif int(current_decision_object.decision_type) == 2 :
        resultVal=cur.execute( "select * from composite_decision where parent_name=%s ",current_decision_object.decision_name)
    childDetails=cur.fetchall()
    for i in range(len(childDetails)):
        rowCount += 1
        if int(current_decision_object.decision_type) == 1 :
            app.logger.info('childDetails[i][1] :- decision_name is:- %s',childDetails[i][1])
            app.logger.info('childDetails[i][2]:- decision_priority is:- %s',childDetails[i][2])
            app.logger.info('childDetails[i][3]:- decision_ssyn_priority is:- %s',childDetails[i][3])
            app.logger.info('childDetails[i][4] :- is_parent is:- %s',childDetails[i][4])
            app.logger.info('childDetails[i][5]:- is_root is:- %s',childDetails[i][5])
            app.logger.info('childDetails[i][6] :- parent_name is:- %s',childDetails[i][6])
            child_object = Childrens( childDetails[i][1],childDetails[i][2],0,childDetails[i][3],childDetails[i][4],childDetails[i][5],childDetails[i][6],1)
            
        elif int(current_decision_object.decision_type) == 2 :
            app.logger.info('childDetails[i][1] :- decision_name is:- %s',childDetails[i][1])
            app.logger.info('childDetails[i][2]:- decision_priority is:- %s',childDetails[i][2])
            app.logger.info('childDetails[i][3]:- decision_syn_priority is:- %s',childDetails[i][3])
            app.logger.info('childDetails[i][4] :- is_parent is:- %s',childDetails[i][4])
            app.logger.info('childDetails[i][5]:- is_root is:- %s',childDetails[i][5])
            app.logger.info('childDetails[i][6] :- parent_name is:- %s',childDetails[i][6])
            child_object = Childrens( childDetails[i][1],childDetails[i][2],childDetails[i][3],0,childDetails[i][4],childDetails[i][5],childDetails[i][6],2)
        childList.append(child_object)
    cur.close()
    return rowCount,childList

def performOperationForTreeBacklog(childObject):
    app.logger.info('Here in performOperationForTreeBacklog ')
    conn=mysql.connect()
    cur=conn.cursor()
    """ mark visited true in resp decision table"""
    if int(childObject.decision_type) == 1:
        cur.execute("update specialized_decision set is_visited=1 where decision_name=%s",childObject.decision_name)
        conn.commit()

    elif int(childObject.decision_type) == 2:
        cur.execute("update composite_decision set is_visited=1 where decision_name=%s",childObject.decision_name)
        conn.commit()
        
    
    cur.execute("delete from current_tree_display where decision_name=%s",childObject.decision_name)
    conn.commit()
    cur.execute("update final_dep set is_visited = 1 where parent_name=%s",childObject.decision_name)
    conn.commit()
    cur.execute("insert into final_decision_order values(null,%s,%s,%s,0,0)",(childObject.decision_name,childObject.decision_sementic_priority,childObject.decision_type))
    conn.commit()
    cur.close()
 
def checkifLeaf(decision_name,decision_type):
    app.logger.info('Here in checkifLeaf ')
    conn=mysql.connect()
    cur=conn.cursor()
    if int(decision_type) == 1:
        resultVal = cur.execute( "select is_parent from specialized_decision where parent_name = %s",decision_name)
    elif int(decision_type) == 2:
        resultVal = cur.execute( "select is_parent from composite_decision where parent_name = %s",decision_name)
    resfree = cur.fetchone()
    cur.close()
    if resfree is None :
        return True
    else :
        return False   
def checkAllLeafDoneForParent(childObject):
    app.logger.info('Here in checkAllLeafDoneForParent ')
    conn=mysql.connect()
    cur=conn.cursor()
    if int(childObject.decision_type) == 1:
        resultVal = cur.execute( "select * from specialized_decision where parent_name = %s and is_visited=0",childObject.decision_name)
    elif int(childObject.decision_type) == 2:
        resultVal = cur.execute( "select * from composite_decision where parent_name = %s and is_visited=0",childObject.decision_name)
    cur.close()
    if int(resultVal) == 0 :
        return True
    else :
        return False
    
    
def getNextDecision():
    app.logger.info('Here in getNextDecision ')
    conn=mysql.connect()
    cur=conn.cursor()
    resultVal = cur.execute("select * from current_tree_display join ( select * from current_tree_display order by is_parent,is_root,decision_ssyn_priority,decision_priority desc,decision_csyn_priority limit 1) d on current_tree_display.decision_type in ( d.decision_type ) where current_tree_display.decision_priority=d.decision_priority and current_tree_display.decision_ssyn_priority=d.decision_ssyn_priority and current_tree_display.decision_csyn_priority=d.decision_csyn_priority")
    
    app.logger.info('resultVal value is :- %s ', resultVal)
    resFree = cur.fetchall()
    cur.close()
    """ decision has been completely made go back to previous backlog"""
    if int(resultVal) == 0 :
        finalBacklogList = getAllIndepedentDecision()
        return render_template('get_priority.html', finalBacklogList=finalBacklogList)
    
    elif int(resultVal) == 1:
        """ means no choice should be given to user """
        """ passing decision_name and decision_type"""
        isLeaf = checkifLeaf(resFree[0][1],resFree[0][7])
        childObject = Childrens(resFree[0][1],resFree[0][2],resFree[0][4],resFree[0][3],resFree[0][5],resFree[0][6],resFree[0][9],resFree[0][7])
        # childObject = Childrens(resFree[0][1],resFree[0][4],resFree[0][3],resFree[0][2],resFree[0][9],resFree[0][6],resFree[0][5],resFree[0][7])
        if isLeaf == True :
            """ print decision, enter in final,remove from tree backlog update in main decision """
            performOperationForTreeBacklog(childObject)
            return render_template('show_tree_decision.html', childObject=childObject) 
        else:
            """ check if childs are traveresed""" 
            allLeafTraversed = checkAllLeafDoneForParent(childObject)
            if allLeafTraversed == True:
                performOperationForTreeBacklog(childObject)
                return render_template('show_tree_decision.html', childObject=childObject)
            else :
                """ not a leaf, then get all its children and their priorities and repeat"""
                decision_object = Decisions(childObject.decision_name,childObject.decision_csyn_priority,childObject.decision_ssyn_priority,childObject.decision_sementic_priority,childObject.decision_type)
                return showDecisionForTree(decision_object)
            
    else:
        """ask user to choose
        next form again do same ifleaf display update ifnot ask prio of children"""
        childList = []
        for i in range(len(resFree)):
        	childObject = Childrens(resFree[i][1],resFree[i][2],resFree[i][4],resFree[i][3],resFree[i][5],resFree[i][6],resFree[i][9],resFree[i][7])
        	childList.append(childObject)
            # childObject = Childrens(resFree[i][1],resFree[i][4],resFree[i][3],resFree[i][2],resFree[i][9],resFree[i][6],resFree[i][5],resFree[i][7])
            
        return render_template('select_tree_conflicting_decision.html', childList=childList)

 
@app.route('/set_tree_conflicting_decision_form',methods=['POST'])
def set_tree_conflicting_decision():
    a = 0
    data = request.form
    for id in data.items():
        a += 1
        list = []
        decision_priority = request.form.get('decision_priority'+str(a))
        decision_name=request.form.get('decision_name'+str(a))
        slectedRadio=request.form.get('selectedRadio')
        decision_type=request.form.get('decision_type'+str(a))
        decision_csyn_priority=request.form.get('decision_csyn_priority'+str(a))
        decision_ssyn_priority=request.form.get('decision_ssyn_priority'+str(a))
        decision_parent_name=request.form.get('decision_parent_name'+str(a))
        decision_is_root=request.form.get('decision_is_root'+str(a))
        decision_is_parent=request.form.get('decision_is_parent'+str(a))
        if decision_name == slectedRadio : 
            app.logger.info('decision_priority is:- %s',decision_priority)
            app.logger.info('decision_name is:- %s',decision_name)
            app.logger.info('slectedRadio is:- %s',slectedRadio)
            app.logger.info('decision_type is:- %s',decision_type)
            app.logger.info('decision_parent_name is:- %s',decision_parent_name)
            app.logger.info('decision_is_parent is:- %s',decision_is_parent)
            decision_object =Decisions(decision_name,decision_csyn_priority,decision_ssyn_priority,decision_priority,decision_type)
            childObject=Childrens(decision_name,decision_priority,decision_csyn_priority,decision_ssyn_priority,decision_parent_name,decision_is_root,decision_is_parent,decision_type)
            if int(decision_is_parent) == 0:
                app.logger.info('inside parent 0')
                performOperationForTreeBacklog(childObject)
                return render_template('show_tree_decision.html', childObject=childObject)
            else :
                """ not a leaf, then get all its children and their priorities and repeat"""
                app.logger.info('inside parent 1')
                return showDecisionForTree(decision_object)
     

@app.route('/get_next_tree_decision_form',methods=['POST'])
def get_next_tree_decision():
    return getNextDecision();


def storeChildPriority(childDecision,priority):
    app.logger.info('Here in storeChildPriority')
    conn=mysql.connect()
    cur=conn.cursor()
    if int(childDecision.decision_type) == 1:
        cur.execute("update specialized_decision set decision_priority=%s where decision_name=%s",(priority,childDecision.decision_name))
        conn.commit()
    elif int(childDecision.decision_type) == 2:
        cur.execute("update composite_decision set decision_priority=%s where decision_name=%s",(priority,childDecision.decision_name))
        conn.commit()


    """ updating the new tree_backlog table """   
    cur.execute("insert into current_tree_display values(Null,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(childDecision.decision_name,priority,childDecision.decision_ssyn_priority,childDecision.decision_csyn_priority,childDecision.decision_is_parent,childDecision.decision_is_root,childDecision.decision_type,0,childDecision.decision_parent_name))
    conn.commit()
    cur.close()
    
   
def showDecisionForTree(current_decision_object):
   
    app.logger.info('Here in showDecisionForTree')
    app.logger.info('For Decision :- %s',current_decision_object.decision_name)
    """1. get all children """
    rowCount,childList = getAllChildren(current_decision_object)
    """ if only one child then no need of taking priority"""
    app.logger.info('rowCount  value is :- %s ',rowCount)
    if int(rowCount) == 1:
        storeChildPriority(childList[0],1)
        return getNextDecision()
    else:
        return render_template('get_child_priorities.html', rowCount=rowCount,childList=childList) 
    

@app.route('/get_child_priority_form',methods=['POST'])
def get_child_priorities():
    app.logger.info('Here in get_child_priorities')
    a = 0
    data = request.form
    maxPriority = []
    for id in data.items():
        a += 1
        decision_name = request.form.get('decision_name'+str(a))
        if decision_name is not None:
            decision_csyn_priority = request.form.get('decision_csyn'+str(a))
            decision_ssyn_priority = request.form.get('decision_ssyn'+str(a))
            decision_type  = request.form.get('decision_type'+str(a))
            decision_priority=request.form.get('priority'+str(a))
            decision_is_parent=request.form.get('decision_is_parent'+str(a))
            decision_parent_name=request.form.get('decision_parent_name'+str(a))
            decision_is_root=request.form.get('decision_is_root'+str(a))
            app.logger.info('decision_name is:- %s',decision_name)
            app.logger.info('decision_csyn_priority :- %s',decision_csyn_priority)
            app.logger.info(' decision_ssyn_priority is:- %s',decision_ssyn_priority)
            app.logger.info(' is_parent is:- %s',decision_is_parent)
            app.logger.info('is_root is:- %s',decision_is_root)
            app.logger.info('parent_name is:- %s',decision_parent_name)
            child_object = Childrens(decision_name,decision_priority,decision_csyn_priority,decision_ssyn_priority,decision_is_parent,decision_is_root,decision_parent_name,decision_type)
            """ sending 2 as for this fucntion , if we give 2nd parameter 1 it will set the decison priority as 1"""
            storeChildPriority(child_object,decision_priority)
    return getNextDecision()

def enterDecisionInTreeTable(decision_object):
    app.logger.info('Here in enterDecisionInTreeTable ')
    conn=mysql.connect()
    cur=conn.cursor()
    if int(decision_object.decision_type) == 1 :
        resultVal = cur.execute("select * from specialized_decision where decision_name=%s",decision_object.decision_name)
        resfree = cur.fetchone()
        app.logger.info('resfree[1] :- decision_name is:- %s',resfree[1])
        app.logger.info('resfree[2] :- decision_priority is:- %s',resfree[2])
        app.logger.info('resfree[3] :- decision_ssyn_priority is:- %s',resfree[3])
        app.logger.info('resfree[4] :- is_parent is:- %s',resfree[4])
        app.logger.info('resfree[5] :- is_root is:- %s',resfree[5])
        app.logger.info('resfree[6] :- parent_name is:- %s',resfree[6])
        app.logger.info('resfree[7] :- is_visited is:- %s',resfree[7])
        cur.execute("insert into current_tree_display values(Null,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(resfree[1],resfree[2],resfree[3],0,resfree[4],resfree[5],1,resfree[7],resfree[6]))
        conn.commit()
    elif int(decision_object.decision_type) ==2 :
        resultVal = cur.execute("select * from composite_decision where decision_name=%s",decision_object.decision_name)
        resfree = cur.fetchone()
        app.logger.info('resfree[1] :- decision_name is:- %s',resfree[1])
        app.logger.info('resfree[2] :- decision_priority is:- %s',resfree[2])
        app.logger.info('resfree[3] :- decision_csyn_priority is:- %s',resfree[3])
        app.logger.info('resfree[4] :- is_parent is:- %s',resfree[4])
        app.logger.info('resfree[5] :- is_root is:- %s',resfree[5])
        app.logger.info('resfree[6] :- parent_name is:- %s',resfree[6])
        app.logger.info('resfree[7] :- is_visited is:- %s',resfree[7])
        cur.execute("insert into current_tree_display values(Null,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(resfree[1],resfree[2],0,resfree[3],resfree[4],resfree[5],2,resfree[7],resfree[6]))
        conn.commit()
    cur.close()  

def updateDecisionTable(decision):
    app.logger.info('Here in updateDecisionTable')
    app.logger.info('Updating for decision :- %s',decision.decision_name)
    conn=mysql.connect()
    cur=conn.cursor()
    rowsAffected = 0
    if int(decision.decision_type) == 0:
        cur.execute("update free_decisions set is_visited = 1,decision_priority=%s where decision_name = %s",(decision.decision_sementic_priority,decision.decision_name))
    elif int(decision.decision_type) == 1:
        cur.execute("update specialized_decision set is_visited = 1,decision_priority=%s where decision_name = %s",(decision.decision_sementic_priority,decision.decision_name))
    elif int(decision.decision_type) == 2:
        cur.execute("update composite_decision set is_visited = 1,decision_priority=%s where decision_name = %s",(decision.decision_sementic_priority,decision.decision_name))

    conn.commit()
    resultVal = cur.execute( "select * from final_dep where parent_name=%s and parent_type=%s",(decision.decision_name,decision.decision_type))
    if resultVal>0:
        rowsAffected += 1
    app.logger.info('Updating final dep table for decision :- %s',decision.decision_name)
    cur.execute("update final_dep set is_visited=1 where parent_name=%s and parent_type=%s",(decision.decision_name,decision.decision_type))
    conn.commit()
    if int(decision.decision_type) == 0:
        cur.execute("insert into final_decision_order values(Null,%s,%s,%s,0,0)",(decision.decision_name,decision.decision_sementic_priority,decision.decision_type))
        conn.commit()
    cur.execute("delete from backlog where decision_name = %s",(decision.decision_name))
    conn.commit()
    cur.close()
    app.logger.info('rowsAffected value is %s',rowsAffected)
    return rowsAffected
    
def getMaxPriority():
    app.logger.info('Here in getMaxPriority')
    conn=mysql.connect()
    cur=conn.cursor()
    rowCount=0;
    list = []
    resultVal=cur.execute( " select * from backlog join ( select * from backlog order by decision_type,decision_ssyn_priority,decision_sementic_priority desc,decision_csyn_priority Limit 1) d on backlog.decision_type in( d.decision_type) where backlog.decision_sementic_priority=d.decision_sementic_priority and backlog.decision_ssyn_priority=d.decision_ssyn_priority and backlog.decision_csyn_priority=d.decision_csyn_priority")
    if resultVal>0:
        resFree = cur.fetchall()
        cur.close()
        for i in range(len(resFree)):
            rowCount += 1
            app.logger.info('decision Name:- %s',resFree[i][1])
            app.logger.info('decision csyn:- %s',resFree[i][2])
            app.logger.info('decision sysyn:- %s',resFree[i][3])
            app.logger.info('decision sem:- %s',resFree[i][4])
            app.logger.info('decision type:- %s',resFree[i][5])
            decision_object = Decisions(resFree[i][1],resFree[i][2],resFree[i][3],resFree[i][4],resFree[i][5])
            list.append(decision_object)
    return rowCount,list
    
def showPriorities():
    """ Get highest priority list """
    app.logger.info('Here in showPriorities')
    """ rowCount tells how many decision are there with conflicting priorities"""
    rowCount,maxPriority = getMaxPriority()
    app.logger.info('Row Count value %s', rowCount)
    """ if rowCount = 1 , display single attribute and update all fields"""
    """ if rowCount >1 , ask the user to select one from them and then repeat"""
    if int(rowCount) == 1 :
        """ updating is_done flag for respective decision and fin_dep table """
        """ here if slected deciion is free than no problem otherwise we have to again ask for child priority)"""
        app.logger.info('Row count value is 1')
        app.logger.info('Current Decision decision_name value is:- %s',maxPriority[0].decision_name)
        app.logger.info('Current Decision decision_type value is:- %s',maxPriority[0].decision_type)
        app.logger.info('Current Decision decision_sementic_priority value is:- %s',maxPriority[0].decision_sementic_priority)
        count_dep=updateDecisionTable(maxPriority[0])
        if maxPriority[0].decision_type == 0:
            return render_template('show_decision.html', count_dep=count_dep,maxPriority=maxPriority[0])
        else:
            enterDecisionInTreeTable(maxPriority[0])
            return showDecisionForTree(maxPriority[0])
    else:
    	return render_template('select_conflicting_decision.html', maxPriority=maxPriority)
        # return render_template('done.html')  
        
        
@app.route('/select_conflicting_decision',methods=['POST'])
def select_conflicting_decision():
    a = 0
    data = request.form
    for id in data.items():
        a += 1
        list = []
        decision_priority = request.form.get('decision_priority'+str(a))
        decision_name=request.form.get('decision_name'+str(a))
        slectedRadio=request.form.get('selectedRadio')
        decision_type=request.form.get('decision_type'+str(a))
        decision_csyn_priority=request.form.get('decision_csyn_priority'+str(a))
        decision_ssyn_priority=request.form.get('decision_ssyn_priority'+str(a))
        if decision_name == slectedRadio : 
            app.logger.info('decision_priority is:- %s',decision_priority)
            app.logger.info('decision_name is:- %s',decision_name)
            app.logger.info('slectedRadio is:- %s',slectedRadio)
            app.logger.info('decision_type is:- %s',decision_type)
            decision_object =Decisions(decision_name,decision_csyn_priority,decision_ssyn_priority,decision_priority,decision_type)
            rowsAffected = updateDecisionTable(decision_object)
            if int(decision_type) == 0 :
                return render_template('show_decision.html', count_dep=rowsAffected,maxPriority=decision_object)
            else :
                enterDecisionInTreeTable(decision_object)
                return showDecisionForTree(decision_object)
    
@app.route('/get_priority',methods=['GET','POST'])
def get_priority(): 
    app.logger.info('in get priorit method')
    app.logger.info('request method is:- %s',request.method)
    if request.method == 'POST':
        a = 0
        data = request.form
        maxPriority = []
        for id in data.items():
            a += 1
            # priority_list=[]
            decision_name = request.form.get('decision_name'+str(a))
            if decision_name is not None:
                decision_csyn_priority = request.form.get('decision_csyn'+str(a))
                decision_ssyn_priority = request.form.get('decision_ssyn'+str(a))
                decision_type  = request.form.get('decision_type'+str(a))
                decision_priority=request.form.get('priority'+str(a))
                # priority_list.append(float(decision_priority))
                """  1. insert given prioirtes in backlog."""
                insertIntoBacklog(decision_name,decision_csyn_priority,decision_ssyn_priority,decision_type,decision_priority)
                app.logger.info('Insertion of priorities in backlog is done')
        app.logger.info('Should print this')
        return showPriorities()
    else:
        finalBacklogList = getAllIndepedentDecision()
        return render_template('get_priority.html', finalBacklogList=finalBacklogList)

def clearBacklog():
    app.logger.info('In Clear backlog')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("delete from backlog")
    conn.commit()
    cur.close()
    
@app.route('/show_decision',methods=['POST'])
def show_decision():   
    total_dependent_row = request.form.get('dependent_rows')
    app.logger.info('dependent row value is %s',total_dependent_row)
    if int(total_dependent_row) > 0:
        clearBacklog()
        finalBacklogList = getAllIndepedentDecision()
        return render_template('get_priority.html', finalBacklogList=finalBacklogList)
    else:
        return showPriorities()

def getNewDecisionId():
    app.logger.info('In getNewDecisionId')
    conn=mysql.connect()
    cur=conn.cursor()
    res = cur.execute("select decision_id,decision_name from decisions where decision_name in ( select decision_name from final_decision_order where is_actionDone=0)")
    a =0;
    if res>0:
        result= cur.fetchall()
        for dec in result:
            if dec is not None:
                app.logger.info('current decisio id :- %s', dec[0])
                rev = cur.execute("select count(*) from action_attr where attr_name in (select distinct(attr_name) from show_info) and action_id = ( select action_id from actions where decision_id = %s)",dec[0])
                isCommon = cur.fetchone()
                app.logger.info('is anything common :- %s ', isCommon)
                if isCommon is not None and int(isCommon[0]) >0:
                    a += 1
                    populateShowInfo(dec[1])
                    UpdateisAction(dec[1])
                    cur.close()
                    return a
    conn.commit()
    cur.close()
    return a
    
""" swati code """
@app.route('/show_intelligence_action',methods=['GET','POST'])
def show_intelligence_action():
    decision_name = request.form.get('decision_name')
    app.logger.info('decision_name :- %s ', decision_name)
    isAvailable=getNewDecisionId()
    if isAvailable >0:
        action_names = getActionNames()
        base_list = getBaseAttributes(action_names,'base')
        derive_list = getBaseAttributes(action_names,'derived')
        return render_template('show_intelligence_action.html', decision_name=decision_name, action_names=action_names,base_attributes=base_list, derived_attributes=derive_list)  
    else :
        conn=mysql.connect()
        cur=conn.cursor()
        resultVal=cur.execute("Select * from final_decision_order")
        print(resultVal)
        if(resultVal>0):
            decisionsDetails=cur.fetchall()
        conn.commit()
        cur.close()
        return render_template('decision_backlog_final_form.html', decisionsDetails=decisionsDetails)
        
        
def setDefaultForIsAction():
    app.logger.info('In setDefaultForIsAction')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("Update final_decision_order set is_actionDone = 0")
    conn.commit()
    cur.close()
    
def UpdateisAction(decision_name):
    app.logger.info('In UpdateisAction')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("Update final_decision_order set is_actionDone = 1 where decision_name = %s",decision_name)
    conn.commit()
    cur.close()   
    
def populateShowInfo(decision_name):
    app.logger.info('In populateShowInfo')
    app.logger.info('Current selected   decision_name  is :- %s',  decision_name)
    conn=mysql.connect()
    cur=conn.cursor()
    res = cur.execute("select decision_id from decisions where decision_name=%s",decision_name)
    decision_id = cur.fetchone()
    app.logger.info('Current selected decision id is :- %s',decision_id)
    rep = cur.execute("select action_id from actions where decision_id=%s",decision_id)
    action_id = cur.fetchone()
    app.logger.info('Current selected action id is :- %s',action_id)
    cur.execute("insert into show_info(action_id,attr_type,attr_name) select action_id, attr_type,attr_name from action_attr where action_id=%s",(action_id))
    conn.commit()
    cur.execute( "update show_info set action_name = ( select action_name from actions where action_id=%s) where action_name is null",action_id)
    conn.commit()
    cur.close()
    
def getActionNames():
    app.logger.info('In getActionNames')
    conn=mysql.connect()
    cur=conn.cursor()
    result = cur.execute( "select distinct(action_name) from show_info")
    actionList = cur.fetchall()
    cur.close()
    return actionList

def getBaseAttributes(action_names,attr_type):
    app.logger.info('In getBaseAttributes')
    conn=mysql.connect()
    cur=conn.cursor()
    list = []
    for action in action_names:
        result = cur.execute( "select attr_name from show_info where attr_type=%s and action_name=%s",(attr_type,action));
        attribute = cur.fetchall()
        list.append(attribute)
    cur.close()
    return list
    
def clearShowInfo():
    app.logger.info('In clearShowInfo')
    conn=mysql.connect()
    cur=conn.cursor()
    result = cur.execute( "delete from show_info");
    conn.commit()
    cur.close()
    
    
@app.route('/decision_backlog_final_form',methods=['GET','POST'])
def decision_backlog_final_form():
    if request.method == 'GET':
        conn=mysql.connect()
        cur=conn.cursor()
        resultVal=cur.execute("Select * from final_decision_order")
        print(resultVal)
        if(resultVal>0):
            decisionsDetails=cur.fetchall()
        conn.commit()
        cur.close()
        return render_template('decision_backlog_final_form.html', decisionsDetails=decisionsDetails)	
    else:
        a = 0
        data = request.form
        for id in data.items():
            a += 1
            if 'form'+str(a) in request.form:
                decision_name = request.form.get('decision_name'+str(a))
                app.logger.info('decision_name is :- %s',decision_name)
                slectedRadio = request.form.get('radio1')
                app.logger.info('slectedRadio is :- %s',slectedRadio)
                if slectedRadio == 'intelligence':
                    clearShowInfo()
                    setDefaultForIsAction()
                    UpdateisAction(decision_name)
                    populateShowInfo(decision_name)
                    action_names = getActionNames()
                    base_list = getBaseAttributes(action_names,'base')
                    derive_list = getBaseAttributes(action_names,'derived')
                    return render_template('show_intelligence_action.html', decision_name=decision_name, action_names=action_names,base_attributes=base_list, derived_attributes=derive_list)
                else:
                    markIsAlternativeDone(decision_name)
                    populateDecisionObjectiveMapTable()
                    markAllAlternativeFree(decision_name)
                    return render_template("get_decision_alternative.html",decision_name=decision_name)
    return render_template('decision_backlog_final_form.html', decisionsDetails=decisionsDetails)

def markAllAlternativeFree(decision_name):
    app.logger.info('In markIsAlternativeDone')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update decision_alternative set is_considered=0 where decision_name=%s",decision_name)
    conn.commit()
    cur.close()
    
def populateDecisionObjectiveMapTable():
    app.logger.info('In populateDecisionObjectiveMapTable')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("delete from decision_objective_map")
    conn.commit()
    cur.execute("insert into decision_objective_map(decision_id,objective_id,objective_name,computable_count) select d.decision_id,d.objective_id,d.objective_name,(select count(*) from objective_attr o where d.objective_id=o.objective_id and computable_attr='computable') from objectives d")
    conn.commit()
    cur.close()

def markIsAlternativeDone(decision_name):
    app.logger.info('In markIsAlternativeDone')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update final_decision_order set is_alternativeDone=1 where decision_name=%s",decision_name)
    conn.commit()
    cur.close()
    
def getAllObjective(decision_name):
    app.logger.info('In getAllObjective')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("select * from objectives where decision_id = ( select decision_id from decisions where decision_name = %s)",decision_name)
    result= cur.fetchall()
    cur.close()
    return result
   

def getAllObjectiveById(decision_id):
    app.logger.info('In getAllObjectiveById')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("select * from objectives where decision_id = %s",decision_id)
    result= cur.fetchall()
    cur.close()
    return result



def storeValueInAlternative(decision_name,val):
    app.logger.info('In storeValueInAlternative')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("insert into decision_alternative values(null,(select decision_id from decisions where decision_name = %s),%s,%s,0)",(decision_name,decision_name,val))
    conn.commit()
    cur.close()

@app.route('/decision_alternative_form',methods=['POST','GET']) 
def storeAlternativeGetobjectivePriority():
    if request.method == 'GET':
        return render_template("get_decision_alternative.html")
    else:
       data = request.form
       a =0;
       for id in data.items():
        a += 1
        decision_name = request.form.get('decision_name')
        val = request.form.get('val'+str(a))
        if decision_name is not None and val is not None:
            app.logger.info('decision_name is :- %s',decision_name)
            app.logger.info('val is :- %s',val)
            storeValueInAlternative(decision_name,val)
       objectiveList = getAllObjective(decision_name)
       return render_template("get_objective_priority.html",objectiveList=objectiveList)


def storePriority(objective_name,priority,decision_id):
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update decision_objective_map set objective_priority = %s where objective_name=%s and decision_id=%s" ,(priority,objective_name,decision_id))
    conn.commit()
    cur.close()
    

def calculatePrioritySum(decision_id):
	conn=mysql.connect()
	cur=conn.cursor()
	resVal=cur.execute("Select sum(objective_priority) from decision_objective_map where decision_id = %s", decision_id)
	if resVal is not None and resVal>0 :
		result=cur.fetchone()
		app.logger.info('result is:- %s ', result[0])
		app.logger.info('result is:- %s ', float(result[0]))
		app.logger.info('float 1:- %s ', float(1))
		if(float(result[0]) ==float(1)):
			cur.close()
			return True
		else:
			cur.execute("update decision_objective_map set objective_priority = 0 where decision_id=%s" ,(decision_id))
			conn.commit()
			cur.close()
			return False


    



@app.route('/get_objective_priority',methods=['POST','GET']) 
def get_objective_priority():
    a = 0
    data = request.form
    decision_id = request.form.get('decision_id')
    for id in data.items():
        a += 1
        objective_name = request.form.get('objective_name'+str(a))
        priority = request.form.get('priority'+str(a))
        app.logger.info('priority  is :- %s',priority)
        if objective_name is not None:
            storePriority(objective_name,priority,decision_id)
    isValid= calculatePrioritySum(decision_id)
    if(isValid == True):
    	app.logger.info('coming in true')
    	return getInfo(decision_id,0,'i')
    else:
    	app.logger.info('coming in false')
    	objectiveList = getAllObjectiveById(decision_id)
    	error_msg="Sum of priorities should be 1"
    	return render_template("get_objective_priority.html",objectiveList=objectiveList,error_msg=error_msg)


def getInfo(decision_id,current_count,caller):
    app.logger.info('In getInfo')
    rowCount,alternativeList = getAllAlternative(decision_id)
    resultval,objectiveList = allObjectiveOfMaxPriority(decision_id)
    if resultval is None or rowCount is None or int(rowCount)== 0 or int(resultval) == 0:
        error = 'no objective/alternative present/left'
        return render_template("confirm_show_info.html",infoCount=current_count,decision_id=decision_id,errorMessage=error )
    else:
        if caller == 'b':
            infoCount = int(current_count)*int(rowCount)
        else:
            infoCount = int(objectiveList[0][2])*int(rowCount) + current_count
        app.logger.info('infoCount  is :- %s',infoCount)

        return render_template("confirm_show_info.html",infoCount=infoCount,decision_id=decision_id )
    
def getAllAlternative(decision_id):
    app.logger.info('In getAllAlternative')
    conn=mysql.connect()
    cur=conn.cursor()
    res = cur.execute("select alternative from decision_alternative where decision_id=%s and is_considered=0",decision_id)
    result = cur.fetchall()
    if res is not None:
        cur.close()
        rowCount = 0
        for i in result:
            rowCount += 1
            app.logger.info('alternative name is :- %s',i[0])
        return rowCount,result
    return None,None
    
def allObjectiveOfMaxPriority(decision_id):
    app.logger.info('In allObjectiveOfMaxPriority')
    conn=mysql.connect()
    cur=conn.cursor()
    resultval =cur.execute("select objective_id,attr_name,(select computable_count from decision_objective_map where decision_id=%s and is_visited=0 order by objective_priority desc limit 1) from objective_attr where computable_attr='computable' and objective_id = ( select objective_id from decision_objective_map where decision_id=%s and is_visited=0 order by objective_priority desc limit 1)",(decision_id,decision_id))
    result = cur.fetchall()
    if resultval>0:
        for i in result:
            app.logger.info('objective_id  is :- %s',i[0])
            app.logger.info('attr_name is :- %s',i[1])
            app.logger.info('count name is :- %s',i[2])
    cur.close()
    return resultval,result

def updatePreviousObjective(decision_id):
    app.logger.info('In updatePreviousObjective')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update decision_objective_map set is_visited=1 where decision_id=%s and is_visited=0 order by objective_priority desc limit 1 ",(decision_id))
    conn.commit()
    cur.close()
 

def getAllObjectiveToShow(decision_id):
    app.logger.info('In getAllObjectiveToShow')
    conn=mysql.connect()
    cur=conn.cursor()
    resultval =cur.execute("select attr_name from objective_attr where computable_attr='computable' and objective_id in ( select objective_id from decision_objective_map where decision_id=%s and is_visited=1)",(decision_id))
    result = cur.fetchall()
    if resultval>0:
        for i in result:
            app.logger.info('attr_name is :- %s',i[0])
    cur.execute("update decision_objective_map set is_visited=1 where decision_id=%s",(decision_id))
    conn.commit()
    cur.close()    
    return resultval,result
      
def setDefaultValues(decision_id):
    app.logger.info('In setDefaultValues')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update decision_objective_map set is_visited=0 where decision_id=%s",(decision_id))
    conn.commit()
    cur.execute("update decision_alternative set is_considered=0 where decision_id=%s ",(decision_id))
    conn.commit()
    cur.close()    
    
@app.route('/confirm_show_info',methods=['POST','GET']) 
def checkShowInfo():
    decision_type = request.form.get('decision')
    decision_id = request.form.get('decision_id')
    infoCount = request.form.get('infoCount')
    buttonValue = request.form.get('error_save')
    app.logger.info('decision_type is :- %s',decision_type)
    app.logger.info('decision_id is :- %s',decision_id)
    app.logger.info('infoCount is :- %s',infoCount)
    if str(buttonValue) is not None and str(buttonValue) == 'error':
        conn=mysql.connect()
        cur=conn.cursor()
        resultVal=cur.execute("Select * from final_decision_order")
        print(resultVal)
        if(resultVal>0):
            decisionsDetails=cur.fetchall()
        conn.commit()
        cur.close()
        return render_template('decision_backlog_final_form.html', decisionsDetails=decisionsDetails)
    if str(decision_type) == "e" :
        app.logger.info('user said is_enough')
        rowCount,alternativeList = getAllAlternative(decision_id)
        updatePreviousObjective(decision_id)
        resultval,objectiveList = getAllObjectiveToShow(decision_id)
        setDefaultValues(decision_id)
        return render_template("final_show_info_alternative_objective.html",infoCount=infoCount,alternativeList=alternativeList,objectiveList=objectiveList )
    elif str(decision_type) == "s" :
        app.logger.info('user said is_small')
        updatePreviousObjective(decision_id)
        return getInfo(decision_id,int(infoCount),'s')
    else :
        app.logger.info('user said is_big')
        rowCount,alternativeList = getAllAlternative(decision_id)
        if rowCount is not None and alternativeList is not None and rowCount != 0:
            return render_template("get_alternative_subset.html",infoCount=infoCount,alternativeList=alternativeList,decision_id=decision_id)          
        else :
            error = 'no objective/alternative present/left'
            return render_template("confirm_show_info.html",infoCount=infoCount,decision_id=decision_id,errorMessage=error )
            
@app.route('/get_alternate_subset',methods=['POST','GET']) 
def reduceTotalInfo():
    multiselect = request.form.getlist('alternative_subset')
    infoCount = request.form.get('infoCount')
    decision_id = request.form.get('decision_id')
    """ it will never be none becz same check is placed just above"""
    count = getCurrentAlternativesCount(decision_id)
    if count == 0:
        newInfoCount = 0
    else:
        newInfoCount = int(infoCount)//int(count[0])
    """ we will set all alternative is_considered = 1 then will one by one change for the given subset"""
    changeIsConsidered(decision_id)
    for alternative in multiselect:
        updateSelectedAlternative(alternative,decision_id)
    return getInfo(decision_id,newInfoCount,'b')
    
def getCurrentAlternativesCount(decision_id):
    app.logger.info('In getCurrentAlternativesCount')
    conn=mysql.connect()
    cur=conn.cursor()
    res=cur.execute("select count(*) from decision_alternative where is_considered=0 and decision_id=%s",decision_id)
    if res is not None and res>0:
        count = cur.fetchone()
        cur.close()
        return count
    conn.commit()
    cur.close() 
    return None
    
def changeIsConsidered(decision_id):
    app.logger.info('In changeIsConsidered')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update decision_alternative set is_considered=1 where decision_id=%s",decision_id)
    conn.commit()
    cur.close()

def updateSelectedAlternative(alternative,decision_id):
    app.logger.info('In updateSelectedAlternative')
    conn=mysql.connect()
    cur=conn.cursor()
    cur.execute("update decision_alternative set is_considered=0 where decision_id=%s and alternative=%s",(decision_id,alternative))
    conn.commit()
    cur.close()
    
dictConfig({
    'version': 1,
    'formatters': {'default': {
        'format': '[%(asctime)s] %(levelname)s in %(module)s: %(message)s',
    }},
    'handlers': {'wsgi': {
        'class': 'logging.StreamHandler',
        'stream': 'ext://flask.logging.wsgi_errors_stream',
        'formatter': 'default'
    }},
    'root': {
        'level': 'INFO',
        'handlers': ['wsgi']
    }
})          

		

	

if __name__=='__main__':
	app.run(debug=True)












