-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2020 at 01:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE `actions` (
  `action_id` int(11) NOT NULL,
  `action_name` varchar(500) DEFAULT NULL,
  `decision_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `action_attr`
--

CREATE TABLE `action_attr` (
  `id` int(11) NOT NULL,
  `action_id` int(11) DEFAULT NULL,
  `attr_name` varchar(300) DEFAULT NULL,
  `data_type` varchar(300) DEFAULT NULL,
  `attr_type` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `action_attr_dep`
--

CREATE TABLE `action_attr_dep` (
  `id` int(11) NOT NULL,
  `action_id` int(11) DEFAULT NULL,
  `attr_name` varchar(300) DEFAULT NULL,
  `child_name` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `backlog`
--

CREATE TABLE `backlog` (
  `backlog_id` int(11) NOT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `decision_csyn_priority` int(11) DEFAULT 0,
  `decision_ssyn_priority` int(11) DEFAULT 0,
  `decision_sementic_priority` decimal(10,9) DEFAULT 0.000000000,
  `decision_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `composite_decision`
--

CREATE TABLE `composite_decision` (
  `decision_id` int(11) NOT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `decision_priority` decimal(10,8) DEFAULT NULL,
  `decision_syn_priority` int(11) DEFAULT 0,
  `is_parent` tinyint(1) DEFAULT NULL,
  `is_root` tinyint(1) DEFAULT 0,
  `parent_name` varchar(300) DEFAULT NULL,
  `is_visited` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `current_tree_display`
--

CREATE TABLE `current_tree_display` (
  `id` int(11) NOT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `decision_priority` decimal(10,1) DEFAULT NULL,
  `decision_ssyn_priority` int(11) DEFAULT NULL,
  `decision_csyn_priority` int(11) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT NULL,
  `is_root` tinyint(1) DEFAULT NULL,
  `decision_type` int(11) DEFAULT NULL,
  `is_visited` tinyint(1) DEFAULT NULL,
  `parent_name` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `decisions`
--

CREATE TABLE `decisions` (
  `decision_id` int(11) NOT NULL,
  `decision_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `decision_alternative`
--

CREATE TABLE `decision_alternative` (
  `id` int(11) NOT NULL,
  `decision_id` int(11) DEFAULT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `alternative` varchar(300) DEFAULT NULL,
  `is_considered` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `decision_objective_map`
--

CREATE TABLE `decision_objective_map` (
  `id` int(11) NOT NULL,
  `decision_id` int(11) DEFAULT NULL,
  `objective_id` int(11) DEFAULT NULL,
  `objective_name` varchar(300) DEFAULT NULL,
  `computable_count` int(11) DEFAULT NULL,
  `objective_priority` decimal(10,9) DEFAULT 0.000000000,
  `is_visited` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `final_decision_order`
--

CREATE TABLE `final_decision_order` (
  `id` int(11) NOT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `decision_priority` decimal(10,1) DEFAULT NULL,
  `decision_type` int(11) DEFAULT NULL,
  `is_actionDone` tinyint(1) DEFAULT 0,
  `is_alternativeDone` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `final_dep`
--

CREATE TABLE `final_dep` (
  `d_id` int(11) NOT NULL,
  `parent_name` varchar(300) DEFAULT NULL,
  `child_name` varchar(300) DEFAULT NULL,
  `is_visited` tinyint(1) DEFAULT 0,
  `parent_type` int(11) NOT NULL,
  `child_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `free_decisions`
--

CREATE TABLE `free_decisions` (
  `decision_id` int(11) NOT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `decision_priority` decimal(10,8) DEFAULT NULL,
  `is_visited` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `objectives`
--

CREATE TABLE `objectives` (
  `objective_id` int(11) NOT NULL,
  `objective_name` varchar(500) DEFAULT NULL,
  `decision_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `objective_attr`
--

CREATE TABLE `objective_attr` (
  `id` int(11) NOT NULL,
  `objective_id` int(11) DEFAULT NULL,
  `attr_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(50) DEFAULT NULL,
  `computable_attr` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `show_info`
--

CREATE TABLE `show_info` (
  `id` int(11) NOT NULL,
  `action_id` int(11) DEFAULT NULL,
  `action_name` varchar(300) DEFAULT NULL,
  `attr_type` varchar(300) DEFAULT NULL,
  `attr_name` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `specialized_decision`
--

CREATE TABLE `specialized_decision` (
  `decision_id` int(11) NOT NULL,
  `decision_name` varchar(300) DEFAULT NULL,
  `decision_priority` decimal(10,8) DEFAULT NULL,
  `decision_syn_priority` int(11) DEFAULT 0,
  `is_parent` tinyint(1) DEFAULT NULL,
  `is_root` tinyint(1) DEFAULT NULL,
  `parent_name` varchar(300) DEFAULT NULL,
  `is_visited` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `uncertainties`
--

CREATE TABLE `uncertainties` (
  `uncertainty_id` int(11) NOT NULL,
  `uncertainty_name` varchar(500) DEFAULT NULL,
  `decision_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `uncertainty_attr`
--

CREATE TABLE `uncertainty_attr` (
  `id` int(11) NOT NULL,
  `uncertainty_id` int(11) DEFAULT NULL,
  `attr_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `actions` (`decision_id`);

--
-- Indexes for table `action_attr`
--
ALTER TABLE `action_attr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `action_attr_dep`
--
ALTER TABLE `action_attr_dep`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `backlog`
--
ALTER TABLE `backlog`
  ADD PRIMARY KEY (`backlog_id`);

--
-- Indexes for table `composite_decision`
--
ALTER TABLE `composite_decision`
  ADD PRIMARY KEY (`decision_id`);

--
-- Indexes for table `current_tree_display`
--
ALTER TABLE `current_tree_display`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `decisions`
--
ALTER TABLE `decisions`
  ADD PRIMARY KEY (`decision_id`);

--
-- Indexes for table `decision_alternative`
--
ALTER TABLE `decision_alternative`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `decision_objective_map`
--
ALTER TABLE `decision_objective_map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `final_decision_order`
--
ALTER TABLE `final_decision_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `final_dep`
--
ALTER TABLE `final_dep`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `free_decisions`
--
ALTER TABLE `free_decisions`
  ADD PRIMARY KEY (`decision_id`);

--
-- Indexes for table `objectives`
--
ALTER TABLE `objectives`
  ADD PRIMARY KEY (`objective_id`),
  ADD KEY `objectives` (`decision_id`);

--
-- Indexes for table `objective_attr`
--
ALTER TABLE `objective_attr`
  ADD PRIMARY KEY (`id`),
  ADD KEY `objective_attr` (`objective_id`);

--
-- Indexes for table `show_info`
--
ALTER TABLE `show_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialized_decision`
--
ALTER TABLE `specialized_decision`
  ADD PRIMARY KEY (`decision_id`);

--
-- Indexes for table `uncertainties`
--
ALTER TABLE `uncertainties`
  ADD PRIMARY KEY (`uncertainty_id`),
  ADD KEY `uncertainties` (`decision_id`);

--
-- Indexes for table `uncertainty_attr`
--
ALTER TABLE `uncertainty_attr`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uncertainty_attr` (`uncertainty_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `action_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `action_attr`
--
ALTER TABLE `action_attr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;

--
-- AUTO_INCREMENT for table `action_attr_dep`
--
ALTER TABLE `action_attr_dep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `backlog`
--
ALTER TABLE `backlog`
  MODIFY `backlog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `current_tree_display`
--
ALTER TABLE `current_tree_display`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `decisions`
--
ALTER TABLE `decisions`
  MODIFY `decision_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `decision_alternative`
--
ALTER TABLE `decision_alternative`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `decision_objective_map`
--
ALTER TABLE `decision_objective_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=892;

--
-- AUTO_INCREMENT for table `final_decision_order`
--
ALTER TABLE `final_decision_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `final_dep`
--
ALTER TABLE `final_dep`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `objectives`
--
ALTER TABLE `objectives`
  MODIFY `objective_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `objective_attr`
--
ALTER TABLE `objective_attr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `show_info`
--
ALTER TABLE `show_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=643;

--
-- AUTO_INCREMENT for table `uncertainties`
--
ALTER TABLE `uncertainties`
  MODIFY `uncertainty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `uncertainty_attr`
--
ALTER TABLE `uncertainty_attr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `actions`
--
ALTER TABLE `actions`
  ADD CONSTRAINT `actions` FOREIGN KEY (`decision_id`) REFERENCES `decisions` (`decision_id`) ON DELETE CASCADE;

--
-- Constraints for table `objectives`
--
ALTER TABLE `objectives`
  ADD CONSTRAINT `objectives` FOREIGN KEY (`decision_id`) REFERENCES `decisions` (`decision_id`) ON DELETE CASCADE;

--
-- Constraints for table `objective_attr`
--
ALTER TABLE `objective_attr`
  ADD CONSTRAINT `objective_attr` FOREIGN KEY (`objective_id`) REFERENCES `objectives` (`objective_id`) ON DELETE CASCADE;

--
-- Constraints for table `uncertainties`
--
ALTER TABLE `uncertainties`
  ADD CONSTRAINT `uncertainties` FOREIGN KEY (`decision_id`) REFERENCES `decisions` (`decision_id`) ON DELETE CASCADE;

--
-- Constraints for table `uncertainty_attr`
--
ALTER TABLE `uncertainty_attr`
  ADD CONSTRAINT `uncertainty_attr` FOREIGN KEY (`uncertainty_id`) REFERENCES `uncertainties` (`uncertainty_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
